/* CrodoMud Proficiency System
 * telnet://crodomud.crodo.com:4000
 * Credits:
 * List Management Functions - Kevin Reid <kpreid@attglobal.net>
 * Everything else added by Cris Jacobin (Muerte of CrodoMud)
*/

#define PROF_VALUE_TYPE  float
#define PROF_TYPE_NONE   0
#define PROF_TYPE_SKILL  1
#define PROF_TYPE_WEAPON 2
#define PROF_WEAP_ADJ  .03

struct prof_data {
  unsigned int     type;
  signed int       key;
  PROF_VALUE_TYPE     value;
  struct prof_data *next;
};

struct prof_file_elem {
  unsigned int  type;  
  signed int    key;
  PROF_VALUE_TYPE  value;
};

/*--- High-Level Interface --------------------------------*/

/* Returns the proficiency value for a given type and key, or -1
   if there is no node. */
PROF_VALUE_TYPE prof_get(struct char_data *ch, int look_type, int look_key);
 
/* Sets the proficiency value for a given type and key, creating
   a node if necessary, or deleting it if the value is <0. */
void prof_set(struct char_data *ch, int look_type, int look_key, PROF_VALUE_TYPE new_val);

/* Frees the entire proficiency list. */
void prof_destroy_all(struct char_data *ch);

/* Loads profs from disk */
int load_profs(struct char_data *ch);

/* Take a wild guess... */
int save_profs(struct char_data *ch);

/* Prof retrieval utilities */
struct prof_data * prof_get_node(struct char_data *ch, int look_type, int look_key);

/* Return prof adjustment for kill */
float prof_adjust(struct char_data *ch);

/* Level prof adjust (class based) */
void prof_slot_gain(struct char_data *ch);

/* Thac0 adjustment */
int prof_apply_thac0(struct char_data *ch);

/* Delete profs file along with char */
int profs_delete_file(struct char_data *ch);
